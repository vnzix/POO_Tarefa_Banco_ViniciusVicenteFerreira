package br.com.main;

import br.com.data.BancoDeDados;
import br.com.model.*;

import java.util.Scanner;

public class Terminal {
    private static BancoDeDados banco = new BancoDeDados();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        int opcao;
        do {
            System.out.println("\n=== MENU BANCO ===");
            System.out.println("1 - Criar Conta Corrente");
            System.out.println("2 - Criar Conta Poupança");
            System.out.println("3 - Listar Contas");
            System.out.println("4 - Realizar Transferência");
            System.out.println("0 - Sair");
            System.out.print("Escolha: ");
            opcao = scanner.nextInt();
            scanner.nextLine();

            switch (opcao) {
                case 1 -> criarConta(true);
                case 2 -> criarConta(false);
                case 3 -> banco.listarContas();
                case 4 -> transferir();
                case 0 -> System.out.println("Saindo...");
                default -> System.out.println("Opção inválida!");
            }
        } while (opcao != 0);
    }

    private static void criarConta(boolean corrente) {
        System.out.print("Nome do titular: ");
        String nome = scanner.nextLine();
        System.out.print("Número da conta: ");
        int numero = scanner.nextInt();
        scanner.nextLine();

        Conta conta = corrente ? new ContaCorrente(numero, nome) : new ContaPoupanca(numero, nome);
        banco.adicionarConta(conta);
        System.out.println("Conta criada com sucesso!");
    }

    private static void transferir() {
        System.out.print("Número da conta origem: ");
        int origem = scanner.nextInt();
        System.out.print("Número da conta destino: ");
        int destino = scanner.nextInt();
        System.out.print("Valor: ");
        double valor = scanner.nextDouble();
        scanner.nextLine();

        Conta c1 = banco.buscarConta(origem);
        Conta c2 = banco.buscarConta(destino);
        if (c1 != null && c2 != null) {
            c1.transferir(c2, valor);
        } else {
            System.out.println("Conta não encontrada!");
        }
    }
}
