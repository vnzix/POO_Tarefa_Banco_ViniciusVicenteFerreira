package br.com.model;

public class ContaCorrente extends Conta {
    public ContaCorrente(int numero, String titular) {
        super(numero, titular);
    }
}
